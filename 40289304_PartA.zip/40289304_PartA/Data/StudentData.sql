-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2021 at 06:39 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obreen01`
--

-- --------------------------------------------------------

--
-- Table structure for table `Student`
--

CREATE TABLE `Student` (
  `StudentID` bigint(20) NOT NULL,
  `StudentName` varchar(255) DEFAULT NULL,
  `DoB` date DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `StudyType` varchar(255) DEFAULT NULL,
  `Date_of_Start` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Student`
--

INSERT INTO `Student` (`StudentID`, `StudentName`, `DoB`, `Address`, `StudyType`, `Date_of_Start`) VALUES
(1, 'Daniel Lee', '1996-05-13', '11 Martin Street', 'Full time', '2015-06-15'),
(2, 'Jenny Parry', '1997-06-15', '210 Kingston Street', 'Full time', '2017-06-30'),
(3, 'Mohan Rashiv', '1998-09-15', '29 Orchard Ave', 'Full time', '2017-06-30'),
(4, 'Laura Park', '1997-04-18', '56 Depak Park', 'Full time', '2018-06-30'),
(5, 'Lewis Shepherd', '1999-12-23', '200 Johnson Ave', 'Full time', '2018-06-30'),
(6, 'Mary Carson', '1996-06-13', '189 Friedman Centers\nFrankmouth, TX 11828', 'Full Time', '2017-06-15'),
(7, 'Alexander Murdock', '1996-04-18', '029 Hart Haven\nPiercefurt, CT 52041', 'Full Time', '2015-06-15'),
(8, 'Kareem Coker', '1998-02-11', '4425 Lisa Station Apt. 314\nNorth Sean, ND 35879', 'Full Time', '2017-06-15'),
(9, 'Harry Hurtado', '1997-02-02', '204 Jennifer Island\nCruzfort, KY 14095', 'Full Time', '2016-06-15'),
(10, 'Jose Abbott', '1996-09-28', '509 Powell Ways\nNorth Lauraside, SD 96141', 'Full Time', '2016-06-30'),
(11, 'Daniel Willard', '1997-04-09', '0637 Brittany Station\nNorth Christopherview, ND 79884', 'Full Time', '2017-06-30'),
(12, 'Bruce Clifton', '1998-03-26', '9742 Pineda Underpass\nNew Hannah, VT 64767', 'Full Time', '2017-06-30'),
(13, 'Sandra Pack', '1997-09-23', '030 Renee Mills\nAllenchester, MN 72480', 'Full Time', '2017-06-15'),
(14, 'Chris Jones', '1997-12-02', '888 Nicholas Mission Suite 732\nPort Brandyfort, NY 64359', 'Full Time', '2018-06-30'),
(15, 'Raymond Pauls', '1997-09-04', '777 Cynthia Shoals\nSouth Stevenhaven, FL 44734', 'Full Time', '2015-06-15'),
(16, 'Lori Nelson', '1997-12-25', '5542 Harper Orchard Suite 665\nMaryland, KS 12781', 'Full Time', '2016-06-15'),
(17, 'Jill Johnson', '1998-03-20', '030 Steven Hill\nLauratown, OH 92346', 'Full Time', '2017-06-30'),
(18, 'Willie Dollar', '1998-04-23', '1969 Shannon Crest Suite 673\nWest Carl, LA 47836', 'Full Time', '2016-06-15'),
(19, 'Larry Aldridge', '1997-12-06', '395 Miles Point Suite 288\nRhodesport, CT 49278', 'Full Time', '2018-06-30'),
(20, 'Paul Smith', '1997-06-03', '9733 Jeffrey Shoals Suite 939\nRobinsonchester, NE 48470', 'Full Time', '2017-06-30'),
(21, 'George Corbett', '1996-09-18', '651 Cervantes Heights\nLinport, WV 45669', 'Full Time', '2017-06-15'),
(22, 'Tracee Lipka', '1996-09-06', '05478 Powers Parks Apt. 631\nTeresafort, TN 80964', 'Full Time', '2016-06-15'),
(23, 'Ronald Wheeler', '1998-11-02', '501 Shelia Ways\nDixonfurt, WA 86594', 'Full Time', '2015-06-15'),
(24, 'Ricardo Glory', '1998-07-16', '63660 Mark Landing Apt. 257\nHarrellstad, NE 95778', 'Full Time', '2017-06-30'),
(25, 'John Yee', '1996-09-05', '345 Stephanie Stream\nHayesport, WI 29681', 'Full Time', '2015-06-30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Student`
--
ALTER TABLE `Student`
  ADD PRIMARY KEY (`StudentID`),
  ADD KEY `StudentID` (`StudentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Student`
--
ALTER TABLE `Student`
  MODIFY `StudentID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
