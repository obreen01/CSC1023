-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2021 at 07:14 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obreen01`
--

-- --------------------------------------------------------

--
-- Table structure for table `Staff`
--

CREATE TABLE `Staff` (
  `StaffID` bigint(20) NOT NULL,
  `Title` varchar(32) DEFAULT NULL,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `DeptID` bigint(20) DEFAULT NULL,
  `CaID` int(11) DEFAULT NULL,
  `Joined` date DEFAULT NULL,
  `LeftD` date DEFAULT NULL,
  `Current` tinyint(1) DEFAULT NULL,
  `Salary` bigint(20) DEFAULT NULL,
  `ContractType` varchar(32) DEFAULT NULL,
  `SupervisorID` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Staff`
--

INSERT INTO `Staff` (`StaffID`, `Title`, `FirstName`, `LastName`, `DeptID`, `CaID`, `Joined`, `LeftD`, `Current`, `Salary`, `ContractType`, `SupervisorID`) VALUES
(1, 'Dr', 'Daniel', 'Dare', 10, 1, '2005-05-13', '2009-01-12', 0, 4000, 'Full time', 5),
(2, 'Lady', 'Sarah', 'Important', 12, 1, '2005-06-15', NULL, 1, 38990, 'Part time', 5),
(3, 'Ms', 'Alice', 'Alive', 10, 1, '2010-06-15', NULL, 1, 35600, 'Part time', 2),
(4, 'Dr', 'Xander', 'Mander', 10, 1, '2010-04-18', NULL, 1, 45790, 'Part time', 3),
(5, 'Professor', 'Jenny', 'Generator', 12, 1, '2011-12-23', NULL, 1, 68000, 'Full time', 4),
(6, 'Ms', 'Gemma', 'Hardasnails', 11, 2, '2011-08-13', NULL, 1, 70000, 'Full time', 2),
(7, 'HRH', 'Prince', 'Caspian', 12, 1, '2017-09-01', NULL, 1, 21000, 'Full time', 5),
(8, 'Mr', 'Brian', 'Knuckles', 10, 3, '2008-07-01', '2010-09-30', 0, 20000, 'Full time', 6),
(9, 'Mr', 'Bob', 'Punch', 13, 1, '2008-07-01', NULL, 1, 37890, 'Full time', 6),
(10, 'Mrs', 'Natalie', 'Nononsense', 10, 1, '2010-10-13', NULL, 1, 29000, 'Full time', 6),
(11, 'Mr', 'Euan', 'Young', 11, 1, '2017-11-11', NULL, 1, 59000, 'Part time', 7),
(12, 'Professor', 'Andrew', 'Brown', 10, 2, '2016-09-21', '2015-05-09', 0, 80420, 'Part time', 5),
(13, 'Mr', 'Mohsin', 'Burks', 11, 4, '2018-06-15', NULL, 1, 21317, 'Full time', 2),
(14, 'Mrs', 'Jadene', 'Crawford', 10, 1, '2010-06-15', NULL, 1, 56701, 'Full time', 2),
(15, 'Dr', 'Pola', 'Halliday', 13, 4, '2010-04-04', '2018-05-05', 0, 60000, 'Full time', 5),
(16, 'HRH', 'Heidi', 'Lloyd', 12, 1, '2015-11-23', NULL, 1, 49060, 'Full time', 20),
(17, 'Professor', 'Oliwia', 'Carroll', 10, 3, '2015-04-01', NULL, 1, 57210, 'Part time', 4),
(18, 'Mr', 'Ramone', 'Rose', 11, 1, '2017-01-09', NULL, 1, 25200, 'Part time', 6),
(19, 'Ms', 'Eva-rose', 'Ashley', 13, 2, '2006-01-07', NULL, 1, 60000, 'Full time', 7),
(20, 'Mrs', 'Charity', 'Mann', 12, 4, '2006-01-07', NULL, 1, 50000, 'Part time', 10),
(21, 'Mrs', 'Animee', 'Amin', 12, 4, '2007-10-13', '2015-02-17', 0, 45610, 'Full time', 6),
(22, 'Mr', 'Ryan', 'Gray', 10, 1, '2007-01-07', NULL, 1, 42040, 'Part time', 2),
(23, 'Professor', 'Niall', 'Cullinan', 11, 2, '2016-09-21', '2019-08-21', 1, 40400, 'Full time', 6),
(24, 'Mr', 'Tomas', 'Brooks', 13, 3, '2005-06-15', NULL, 1, 35590, 'Full time', 2),
(25, 'Ms', 'Jasper', 'Thomas', 14, 1, '2010-06-15', NULL, 1, 71923, 'Part time', 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Staff`
--
ALTER TABLE `Staff`
  ADD PRIMARY KEY (`StaffID`),
  ADD KEY `DeptID` (`DeptID`),
  ADD KEY `CaID` (`CaID`),
  ADD KEY `StaffID` (`StaffID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Staff`
--
ALTER TABLE `Staff`
  MODIFY `StaffID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Staff`
--
ALTER TABLE `Staff`
  ADD CONSTRAINT `Staff_ibfk_1` FOREIGN KEY (`DeptID`) REFERENCES `Department` (`DeptID`),
  ADD CONSTRAINT `Staff_ibfk_2` FOREIGN KEY (`CaID`) REFERENCES `Campus` (`CaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
