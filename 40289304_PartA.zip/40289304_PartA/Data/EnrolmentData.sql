-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2021 at 06:46 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obreen01`
--

-- --------------------------------------------------------

--
-- Table structure for table `Enrolment`
--

CREATE TABLE `Enrolment` (
  `EID` bigint(20) NOT NULL,
  `StudentID` bigint(20) DEFAULT NULL,
  `ModuleID` bigint(20) DEFAULT NULL,
  `Score` int(11) DEFAULT NULL,
  `Semester` varchar(255) DEFAULT NULL,
  `Year` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Enrolment`
--

INSERT INTO `Enrolment` (`EID`, `StudentID`, `ModuleID`, `Score`, `Semester`, `Year`) VALUES
(1, 1, 1, 85, 'S1', 2020),
(2, 2, 2, 76, 'S2', 2020),
(3, 3, 3, 88, 'S1', 2020),
(4, 4, 1, 90, 'S1', 2019),
(5, 5, 4, 87, 'S2', 2020),
(11, 53, 1, 43, 'S1', 2018),
(12, 54, 1, 84, 'S1', 2018),
(13, 55, 1, 52, 'S1', 2018),
(14, 56, 1, 65, 'S1', 2018),
(15, 57, 1, 84, 'S1', 2018),
(16, 58, 1, 85, 'S1', 2018),
(17, 59, 1, 22, 'S1', 2018),
(18, 60, 1, 55, 'S1', 2018),
(19, 61, 1, 19, 'S1', 2018),
(20, 62, 1, 33, 'S1', 2018),
(21, 63, 1, 65, 'S1', 2018),
(22, 64, 1, 56, 'S1', 2018),
(23, 65, 1, 84, 'S1', 2018),
(24, 66, 1, 96, 'S1', 2018),
(25, 67, 1, 85, 'S1', 2018),
(26, 68, 1, 25, 'S1', 2018),
(27, 69, 1, 63, 'S1', 2018),
(28, 70, 1, 66, 'S1', 2018),
(29, 71, 1, 65, 'S1', 2018),
(30, 72, 1, 67, 'S1', 2018);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Enrolment`
--
ALTER TABLE `Enrolment`
  ADD PRIMARY KEY (`EID`),
  ADD KEY `ModuleID` (`ModuleID`),
  ADD KEY `EID` (`EID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Enrolment`
--
ALTER TABLE `Enrolment`
  MODIFY `EID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Enrolment`
--
ALTER TABLE `Enrolment`
  ADD CONSTRAINT `Enrolment_ibfk_1` FOREIGN KEY (`ModuleID`) REFERENCES `Module` (`ModuleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
