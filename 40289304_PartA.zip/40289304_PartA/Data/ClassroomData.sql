-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 19, 2021 at 07:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obreen01`
--

-- --------------------------------------------------------

--
-- Table structure for table `Classroom`
--

CREATE TABLE `Classroom` (
  `RmID` bigint(20) NOT NULL,
  `Capacity` bigint(20) DEFAULT NULL,
  `CaID` int(11) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Type` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Classroom`
--

INSERT INTO `Classroom` (`RmID`, `Capacity`, `CaID`, `Location`, `Type`, `Status`) VALUES
(1, 50, 2, 'MM Tower, 23 Lewis Avenue Belfast', 'Classroom', 'Open'),
(2, 100, 2, 'CS Bldg, 24 Lewis Avenue Belfast', 'Classroom', 'Open'),
(3, 75, 2, 'CS Bldg, 24 Lewis Avenue Belfast', 'Classroom', 'Open'),
(4, 200, 1, 'Basement, 123 PalmBeach Street London', 'Hall', 'Ready to Open'),
(5, 25, 3, '1St Floor, 231 Raffles Street Singapore', 'Classroom', 'Under Repair'),
(6, 200, 4, '2nd Floor, 42 Wallaby Way, Sydney', 'Classroom', 'Open');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Classroom`
--
ALTER TABLE `Classroom`
  ADD PRIMARY KEY (`RmID`),
  ADD KEY `CaID` (`CaID`),
  ADD KEY `RmID` (`RmID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Classroom`
--
ALTER TABLE `Classroom`
  MODIFY `RmID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Classroom`
--
ALTER TABLE `Classroom`
  ADD CONSTRAINT `Classroom_ibfk_1` FOREIGN KEY (`CaID`) REFERENCES `Campus` (`CaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
